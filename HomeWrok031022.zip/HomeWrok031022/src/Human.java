public class Human {

    private String name;
    private String height;
    private String city;

    public Human() {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        city = city;
    }

    public void info(){
        System.out.printf("I am %s, I was born in %s and nowadays my height is %s",name,city,height);
    }

}
