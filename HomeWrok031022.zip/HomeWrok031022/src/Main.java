import java.util.Scanner;

    public class Main {

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.println("First person info");
            Human person1 = new Human();
            person1.setName(sc.nextLine());
            person1.setCity(sc.nextLine());
            person1.setHeight(sc.nextLine());
            person1.info();
        }
    }
